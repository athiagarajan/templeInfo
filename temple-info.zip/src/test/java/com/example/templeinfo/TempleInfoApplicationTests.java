package com.example.templeinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TempleInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
